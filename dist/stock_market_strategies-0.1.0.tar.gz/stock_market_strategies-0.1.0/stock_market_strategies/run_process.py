# First, generate the sample data
exec(open('generate_sample_data.py').read())

# Then run the main program
exec(open('main.py').read())