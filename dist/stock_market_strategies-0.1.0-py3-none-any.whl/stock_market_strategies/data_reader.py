import pandas as pd
from typing import Dict
import os

class DataReader:
    def __init__(self, data_dir: str):
        self.data_dir = data_dir

    def read_stock_data(self, symbols: list) -> Dict[str, pd.DataFrame]:
        stock_data = {}
        for symbol in symbols:
            file_path = os.path.join(self.data_dir, f"{symbol}.csv")
            if os.path.exists(file_path):
                df = pd.read_csv(file_path, index_col='Date', parse_dates=True)
                stock_data[symbol] = df
            else:
                print(f"Data for {symbol} not found.")
        return stock_data