import pandas as pd
from typing import Dict

def sma_crossover(data: pd.DataFrame, short_window: int = 50, long_window: int = 200) -> bool:
    short_sma = data['Close'].rolling(window=short_window).mean()
    long_sma = data['Close'].rolling(window=long_window).mean()
    return short_sma.iloc[-1] > long_sma.iloc[-1]

def rsi_oversold(data: pd.DataFrame, window: int = 14, threshold: int = 30) -> bool:
    delta = data['Close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi.iloc[-1] < threshold

class StrategyAnalyzer:
    def __init__(self, stock_data: Dict[str, pd.DataFrame]):
        self.stock_data = stock_data

    def analyze(self, strategies: list) -> pd.DataFrame:
        results = []
        for symbol, data in self.stock_data.items():
            row = {'Symbol': symbol}
            for strategy in strategies:
                if strategy == 'SMA Crossover':
                    row[strategy] = int(sma_crossover(data))
                elif strategy == 'RSI Oversold':
                    row[strategy] = int(rsi_oversold(data))
            results.append(row)
        return pd.DataFrame(results)