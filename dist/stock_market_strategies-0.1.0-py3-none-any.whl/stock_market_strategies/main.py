from src.data_reader import DataReader
from src.strategies import StrategyAnalyzer
from src.backtesting import Backtester

def main():
    print("Welcome to Stock Market Strategies")
    
    # Step 1: Read data
    data_reader = DataReader('data/stock_data')
    stock_data = data_reader.read_stock_data(['AAPL', 'GOOGL', 'MSFT'])
    print("Data loaded successfully.")

    # Step 2: Analyze strategies
    analyzer = StrategyAnalyzer(stock_data)
    strategy_results = analyzer.analyze(['SMA Crossover', 'RSI Oversold'])
    print("\nStrategy Analysis Results:")
    print(strategy_results)

    # Step 3: Run backtest
    backtester = Backtester(stock_data, strategy_results)
    backtest_results = backtester.run_backtest('2022-01-01', '2022-12-31')
    print("\nBacktest Results:")
    print(backtest_results)

if __name__ == "__main__":
    main()