import pandas as pd
from typing import Dict

class Backtester:
    def __init__(self, stock_data: Dict[str, pd.DataFrame], strategy_results: pd.DataFrame):
        self.stock_data = stock_data
        self.strategy_results = strategy_results

    def run_backtest(self, start_date: str, end_date: str) -> pd.DataFrame:
        results = []
        for strategy in self.strategy_results.columns[1:]:
            strategy_results = self._backtest_strategy(strategy, start_date, end_date)
            results.append(strategy_results)
        return pd.DataFrame(results)

    def _backtest_strategy(self, strategy: str, start_date: str, end_date: str) -> Dict:
        trades = []
        for symbol in self.strategy_results[self.strategy_results[strategy] == 1]['Symbol']:
            stock_data = self.stock_data[symbol].loc[start_date:end_date]
            
            in_position = False
            for i in range(1, len(stock_data)):
                if not in_position and stock_data.iloc[i]['Close'] > stock_data.iloc[i-1]['Close']:
                    entry_price = stock_data.iloc[i]['Open']
                    entry_date = stock_data.index[i]
                    in_position = True
                elif in_position and stock_data.iloc[i]['Close'] < stock_data.iloc[i-1]['Close']:
                    exit_price = stock_data.iloc[i]['Open']
                    exit_date = stock_data.index[i]
                    trades.append({
                        'symbol': symbol,
                        'entry_date': entry_date,
                        'exit_date': exit_date,
                        'entry_price': entry_price,
                        'exit_price': exit_price,
                        'return': (exit_price - entry_price) / entry_price
                    })
                    in_position = False

        trades_df = pd.DataFrame(trades)
        abs_return = trades_df['return'].sum() if len(trades_df) > 0 else 0
        hit_ratio = (trades_df['return'] > 0).mean() if len(trades_df) > 0 else 0
        avg_gain = trades_df[trades_df['return'] > 0]['return'].mean() if len(trades_df[trades_df['return'] > 0]) > 0 else 0
        avg_loss = trades_df[trades_df['return'] < 0]['return'].mean() if len(trades_df[trades_df['return'] < 0]) > 0 else 0

        return {
            'Strategy_name': strategy,
            'Abs Return': abs_return,
            'Hit Ratio': hit_ratio,
            'Average Gain': avg_gain,
            'Average Loss': avg_loss
        }